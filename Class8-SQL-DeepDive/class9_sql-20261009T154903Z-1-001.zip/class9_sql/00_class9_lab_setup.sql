-- NEW beginner Class 9 pack. MySQL 8.0.18+ / InnoDB.
-- Run this file ONCE before class on each disposable learner instance.
-- If database already exists, STOP; use reset only after verifying its schema.
-- Does not change meridian_retail or the older fde_class9_lab.
CREATE DATABASE fde_class9_beginner_lab;
USE fde_class9_beginner_lab;
CREATE TABLE lab_cases (
  case_id VARCHAR(20) NOT NULL PRIMARY KEY,
  review_status VARCHAR(20) NOT NULL,
  current_decision VARCHAR(30) NULL,
  version INT NOT NULL,
  CONSTRAINT chk_c9_status CHECK (review_status IN ('PENDING','REVIEWED')),
  CONSTRAINT chk_c9_decision CHECK (current_decision IS NULL OR
    current_decision IN ('NEEDS_INFO','READY_FOR_HANDOFF')),
  CONSTRAINT chk_c9_version CHECK (version >= 1)
) ENGINE=InnoDB;
CREATE TABLE lab_reviews (
  review_id VARCHAR(30) NOT NULL PRIMARY KEY,
  case_id VARCHAR(20) NOT NULL,
  reviewer VARCHAR(20) NOT NULL,
  decision VARCHAR(30) NOT NULL,
  CONSTRAINT chk_c9_review_decision CHECK
    (decision IN ('NEEDS_INFO','READY_FOR_HANDOFF')),
  CONSTRAINT fk_c9_case FOREIGN KEY (case_id) REFERENCES lab_cases(case_id)
    ON DELETE RESTRICT
) ENGINE=InnoDB;
INSERT INTO lab_cases (case_id,review_status,current_decision,version)
VALUES ('C9-DEMO','PENDING',NULL,1), ('C9-PRACTICE','PENDING',NULL,1);
SELECT * FROM lab_cases ORDER BY case_id;
